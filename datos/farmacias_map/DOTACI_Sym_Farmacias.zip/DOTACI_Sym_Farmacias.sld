<StyledLayerDescriptor xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://www.opengis.net/sld http://schemas.opengis.net/sld/1.0.0/StyledLayerDescriptor.xsd"
  version="1.0.0">
	<NamedLayer>
		<Name>IDENA_DOTACI_Sym_Farmacias</Name>
		<UserStyle>
			<Name>IDENA_DOTACI_Sym_Farmacias</Name>
			<Title>IDENA_DOTACI_Sym_Farmacias</Title>
			<FeatureTypeStyle>
				<Name>Name</Name>
				<Rule>
					<MinScaleDenominator>299000</MinScaleDenominator>
					<MaxScaleDenominator>1000000</MaxScaleDenominator>
						<PointSymbolizer>
							<Graphic>
								<Mark>
									<WellKnownName>square</WellKnownName>
									<Fill>
										<CssParameter name="fill">#019801</CssParameter>
									</Fill>
									<Stroke>
										<CssParameter name="stroke">#019801</CssParameter>
										<CssParameter name="stroke-width">1</CssParameter>
									</Stroke>
								</Mark>
								<Size>6</Size>
							</Graphic>
						</PointSymbolizer>
				</Rule>
				<Rule>
					<MaxScaleDenominator>300000</MaxScaleDenominator>
					<PointSymbolizer>
						<Graphic>
							<ExternalGraphic>
								<OnlineResource 
                    xlink:type="simple"
                    xlink:href="DOTACI_Sym_Farmacias.svg" />
								<Format>image/svg+xml</Format>
							</ExternalGraphic>
							<Size>25</Size>
						</Graphic>
					</PointSymbolizer>
				</Rule>
				<Rule>
					<MaxScaleDenominator>2000</MaxScaleDenominator>
					<TextSymbolizer>
						<Label>
							<ogc:PropertyName>TITULAR</ogc:PropertyName>
						</Label>
						<Font>
							<CssParameter name="font-family">Calibri</CssParameter>
							<CssParameter name="font-size">11</CssParameter>
							<CssParameter name="font-style">normal</CssParameter>
							<CssParameter name="font-weight">bold</CssParameter>
						</Font>
						<LabelPlacement>
							<PointPlacement>
								<AnchorPoint>
									<AnchorPointX>1.10</AnchorPointX>
									<AnchorPointY>0.25</AnchorPointY>
								</AnchorPoint>
								<Displacement>
									<DisplacementX>-2</DisplacementX>
									<DisplacementY>0</DisplacementY>
								</Displacement>
							</PointPlacement>
						</LabelPlacement>
						<Halo>
							<Radius>2</Radius>
							<Fill>
								<CssParameter name="fill">#F0F0F0</CssParameter>
							</Fill>
						</Halo>
						<Fill>
							<CssParameter name="fill">#000000</CssParameter>
						</Fill>
   
				</TextSymbolizer>
				</Rule>
			</FeatureTypeStyle>
		</UserStyle>
	</NamedLayer>
</StyledLayerDescriptor>